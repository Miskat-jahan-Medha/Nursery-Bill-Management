package manager;
import java.lang.*;
import entity.*;
import interfaces.*;
public class Inventory implements IInventoryOperations{
	private NurseryItem[] nurseryItem;
	public Inventory(){
		  nurseryItem = new NurseryItem[10000];

	}
	public Inventory(int size){
		nurseryItem = new NurseryItem[size];
	}
	public void addNurseryItem(int itemNo,NurseryItem nItem){
		if(itemNo>=0 && itemNo < nurseryItem.length){
			nurseryItem[itemNo] = nItem;
		} else {
        System.out.println("Invalid item number!");
    }
	}
	
	public NurseryItem getNursery_Item(int itemNo){
		return nurseryItem[itemNo];
	}
	
	public NurseryItem getNursery_ItemById(String id){
		for(NurseryItem nItem : nurseryItem){//for-each loop
			if(nItem!=null && nItem.getId().equals(id)){
				return nItem;
			}
		}
		return null;
	}
	/*public NurseryItem getNursery_ItemById(String id){
		for(int i=0; i<nurserytItem.length; i++){
			if(nItem!=null){
				nItem.displayDetails();
			}
		}
	}*/public void remove(int itemNo){
    if(itemNo >= 0 && itemNo < nurseryItem.length){
        nurseryItem[itemNo] = null;
    }
}
	
	public void showInventory(){
    System.out.println("------- Inventory Details --------");
    for(NurseryItem nItem : nurseryItem){
        if(nItem != null){
            nItem.displayDetails();
        }
    }
    System.out.println("-----------------");
    }
	
	 public String toString(){
    String allData = "";   
    allData += "------- Inventory Details -------\n";
    for(NurseryItem nItem : nurseryItem){
        if(nItem != null){
            allData += nItem.toString();
        }
    }
    allData += "-------------------------------------------\n";
    
    return allData;
    }
}
		
    
