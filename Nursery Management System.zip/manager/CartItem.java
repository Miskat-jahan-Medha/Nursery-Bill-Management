package manager;
import entity.*;
public class CartItem{
	private NurseryItem nurseryItem;
	private double quantity;
	public CartItem(NurseryItem nurseryItem, double quantity){
		setNurseryItem(nurseryItem);
		setQuantity(quantity);
	}
	public void setNurseryItem(NurseryItem nurseryItem){
		this.nurseryItem = nurseryItem;
	}
	public NurseryItem getNurseryItem(){
		return nurseryItem;
	}
	
	public void setQuantity(double quantity){
		if(quantity>0){
			this.quantity = quantity;
		}
	}
	
	public double getQuantity(){
		return quantity;
	}
	
	public double getBill(){
		return nurseryItem.getPrice()*quantity;
	}
	
	public void sellNurseryItem(){
		nurseryItem.sellQuantity(quantity);
	}
	
	public void showItem(){
		System.out.println(nurseryItem.getId()+" | "+nurseryItem.getName()+" | "+nurseryItem.getPrice()+" | "+ quantity+ " | "+ getBill() );
	}
}