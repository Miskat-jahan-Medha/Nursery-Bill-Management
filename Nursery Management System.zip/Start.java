import java.lang.*;
import entity.*;
import manager.*;
import gui.*;

import javax.swing.*;

public class Start {
    public static void main(String[] args) {		
		
		InventoryPage ip = new InventoryPage();
		
   }
}