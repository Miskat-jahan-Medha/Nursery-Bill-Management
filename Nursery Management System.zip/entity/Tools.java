package entity;
public class Tools extends NurseryItem{
	private String type;
	private String material;
	public Tools(){
		super();
		System.out.println("E-Tools");
	}
	public Tools(String id,String name,double price,double quantity,String type,String material){
		super(id,name,price,quantity);
		System.out.println("C-Tools");
		setType(type);
		setMaterial(material);
	}
	public void setType(String type){
		if(!type.isEmpty()){
		this.type=type;
		}
		else{
			System.out.println("Invalid Type");
		}
	}
	public String getType(){
		return type;
	}
	public void setMaterial(String material){
		if(!material.isEmpty()){
		this.material=material;
		}
		else{
			System.out.println("Invalid Material Name");
		}
	}
	public String getMaterial(){
		return material;
	}
	
	
	@Override
	public void displayDetails(){
		System.out.println("Id: "+super.getId());
		System.out.println("Name: "+super.getName());
		System.out.println("Price: "+super.getPrice());
		System.out.println("Type:"+type);
		System.out.println("Material:"+material);
		System.out.println("Quantity : "+super.getQuantity());
		System.out.println("............................");
	}
	
	
	@Override
	public String toString(){
		String data = "";
		data+= "Id: "+super.getId()+"\n";
		data+= "Name: "+super.getName()+"\n";
		data+= "Price: "+super.getPrice()+"\n";
		data+= "Type :"+type+"\n";
		data+= "Material: "+material+"\n";
		data+= "Quantity : "+super.getQuantity()+"\n";
		data+= "............................"+"\n";
		
		return data;
	}
}