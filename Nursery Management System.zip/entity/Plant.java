package entity;
public class Plant extends NurseryItem{
	private String category;
	private String season;
	public Plant(){
		super();
		System.out.println("E-Plant");
	}
	public Plant(String id,String name,double price,double quantity,String category,String season){
		super( id, name, price, quantity);
		System.out.println("C-Plant");
		setCategory(category);
		setSeason(season);
	}
	public void setCategory(String category){
		if(!category.isEmpty()){
		this.category=category;
		}
		else{
			System.out.println("Invalid Category");
		}
	}
	public String getCategory(){
		return category;
	}
	public void setSeason(String season){
		if(!season.isEmpty()){
		this.season=season;
		}
		else{
			System.out.println("Invalid Season");
		}
	}
	public String getSeason(){
		return season;
	}
	
	
	@Override
	public void displayDetails(){
		System.out.println("Id: "+super.getId());
		System.out.println("Name: "+super.getName());
		System.out.println("Price: "+super.getPrice());
		System.out.println("Category:"+category);
		System.out.println("Season:"+season);
		System.out.println("Quantity : "+super.getQuantity());
		System.out.println("............................");
	}
	
	
	@Override
	public String toString(){
		String data = "";
		data+= "Id: "+super.getId()+"\n";
		data+= "Name: "+super.getName()+"\n";
		data+= "Price: "+super.getPrice()+"\n";
		data+= "Category :"+category+"\n";
		data+= "Season: "+season+"\n";
		data+= "Quantity : "+super.getQuantity()+"\n";
		data+= "............................"+"\n";
		
		return data;
	}
}