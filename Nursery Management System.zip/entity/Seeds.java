  package entity;
public class Seeds extends NurseryItem{
	private String category;
	private String expiryDate;
	public Seeds(){
		super();
		System.out.println("E-Seeds");
	}
	public Seeds(String id,String name,double price,double quantity,String category,String expiryDate){
		super(id,name,price,quantity);
		System.out.println("C-Seeds");
		setCategory(category);
		setExpiryDate(expiryDate);
	}
	public void setCategory(String category){
		if(!category.isEmpty()){
		this.category=category;
		}
		else{
			System.out.println("Invalid Category");
		}
	}
	public String getCategory(){
		return category;
	}
	public void setExpiryDate(String expiryDate){
		if(!expiryDate.isEmpty()){
		this.expiryDate=expiryDate;
		}
		else{
			System.out.println("Invalid Expiry Date");
		}
	}
	public String getExpiryDate(){
		return expiryDate;
	}
	
	
	@Override
	public void displayDetails(){
		System.out.println("Id: "+super.getId());
		System.out.println("Name: "+super.getName());
		System.out.println("Price: "+super.getPrice());
		System.out.println("Category:"+category);
		System.out.println("Season:"+expiryDate);
		System.out.println("Quantity : "+super.getQuantity());
		System.out.println("............................");
	}
	
	
	@Override
	public String toString(){
		String data = "";
		data+= "Id: "+super.getId()+"\n";
		data+= "Name: "+super.getName()+"\n";
		data+= "Price: "+super.getPrice()+"\n";
		data+= "Category :"+category+"\n";
		data+= "Season: "+expiryDate+"\n";
		data+= "Quantity : "+super.getQuantity()+"\n";
		data+= "............................"+"\n";
		
		return data;
	}
}