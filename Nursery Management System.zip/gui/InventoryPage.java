package gui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*; 

import entity.*; 
import manager.*;
import files.*;

public class InventoryPage implements ActionListener{
	JFrame frame = new JFrame("Inventory Page");
	Font font15 = new Font("Cambria",Font.BOLD,15);
	Font font20 = new Font("Cambria",Font.BOLD,20);
	
	JLabel billIdLabel, itemIdLabel, quantityLabel, customerIdLabel;
	
	JTextField billIdField, itemIdField, quantityField, customerIdField;
	
	JButton addToCartBtn, cleanBtn, updateBtn, discountBtn, calculateBillBtn, confirmOrderBtn;
	
	
	JTextArea billScreen;       // for Bill details
    JTextArea inventoryScreen;  // for Inventory details
	
	
	Inventory inventory = new Inventory(500);
	Cart cart = new Cart(100);  // for storing cart items
	
	public InventoryPage(){
		frame.setSize(1000,600);//w, h
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setIconImage(new ImageIcon("./images/icon.png").getImage());
		
		//////////********
		
		//========== Inventory Data Initialization =======
		//Load From File
		FileIO.loadFromFile(inventory);
		
		//================================================
		
		JLabel welcomeLabel = new JLabel("Welcome to Nursery Billing System ");
		welcomeLabel.setBounds(10,10,400,30);//x,y,w,h
		welcomeLabel.setFont(font15);
		welcomeLabel.setOpaque(true);
		welcomeLabel.setBackground(new Color(84,253,218));
		welcomeLabel.setForeground(Color.BLACK);
		frame.add(welcomeLabel);
		
		
		int x=10, y=50, w=100, h=30, xGap= 10, yGap=10;
		
		billIdLabel = createLabel(x,y,w,h,"Bill ID");
		billIdField = createTextField(x+w+xGap,y,w,h,"");
		y += h+yGap;
		
		itemIdLabel = createLabel(x,y,w,h,"Item ID");
		itemIdField = createTextField(x+w+xGap,y,w,h,"");
		y += h+yGap;
		
		quantityLabel = createLabel(x,y,w,h,"Quantity");
		quantityField = createTextField(x+w+xGap,y,w,h,"");
		y += h+yGap;
		
		addToCartBtn = createButton(x,y,210,h,"Add to Cart");
		addToCartBtn.setBackground(Color.GREEN);
		y += h+yGap;
		
		cleanBtn = createButton(x,y,210,h,"Clean");
		cleanBtn.setBackground(Color.GREEN);
		y += h+yGap;
		
		updateBtn = createButton(x,y,210,h,"Update");
		updateBtn.setBackground(Color.GREEN);
		y += h+yGap;
		
		customerIdLabel = createLabel(x, y,w,h, "Customer ID:");
        customerIdField = createTextField(x+w+xGap,y,w,h,"");
        y += h+yGap;
		
		discountBtn = createButton(x,y,210,h,"Discount");
		discountBtn.setBackground(Color.GREEN);
		y += h+yGap;


		calculateBillBtn = createButton(x,y,210,h,"Calculate Bill");
		calculateBillBtn.setBackground(Color.GREEN);
		y += h+yGap;
		
		
		confirmOrderBtn = createButton(x,y,210,h,"Confirm Order");
		confirmOrderBtn.setBackground(Color.GREEN);
		y += h+yGap;
		
		// Bill Screen (Left Side)
        billScreen = new JTextArea();
        billScreen.setFont(font15);
        billScreen.setEditable(false);
        JScrollPane billJsp = new JScrollPane(billScreen);
        billJsp.setBounds(310, 50, 320, 450);
        frame.add(billJsp);

        // Inventory Screen (Right Side)
        inventoryScreen = new JTextArea();
        inventoryScreen.setFont(font15);
        inventoryScreen.setEditable(false);
        JScrollPane invJsp = new JScrollPane(inventoryScreen);
        invJsp.setBounds(650, 50, 320, 450);
        frame.add(invJsp);

        updateInventoryScreen();

        frame.setVisible(true);
	}
	
	public JLabel createLabel(int x,int y, int w, int h, String text){
		JLabel label = new JLabel(text);
		label.setBounds(x,y,w,h);
		label.setFont(font15);
		label.setOpaque(true);
		label.setBackground(new Color(84,253,218));
		label.setForeground(Color.BLACK);
		frame.add(label);
		return label;
	}
	
		
	public JTextField createTextField(int x,int y, int w, int h, String text){
		JTextField field = new JTextField(text);
		field.setBounds(x,y,w,h);
		field.setFont(font15);
		frame.add(field);
		return field;
	}
	
	
	public JButton createButton(int x,int y, int w, int h, String text){
		JButton button = new JButton(text);
		button.setBounds(x,y,w,h);
		button.setFont(font15);
		button.addActionListener(this);
		frame.add(button);
		return button;
	}
	
	
	
	
	public void actionPerformed(ActionEvent ae){
		
		if(ae.getSource() == addToCartBtn){
			System.out.println("Add TO Cart Button Clicked");
			
			
			if(!billIdField.getText().isEmpty() && 
			!itemIdField.getText().isEmpty() &&
			!quantityField.getText().isEmpty()){ 
			
				String billId = billIdField.getText();
				String itemId = itemIdField.getText();
				double quantity = Double.parseDouble( quantityField.getText() );

				NurseryItem nItem = inventory.getNursery_ItemById(itemId);
				/*inventory.addProduct(no, new Electronics(id,name,price,quantity,months));
				updateTextArea();	
				
				JOptionPane.showMessageDialog(frame,"New Product Added.");*/
				
				
				if (nItem != null && nItem.getQuantity() >= quantity) {
                    cart.addNurseryItem(Integer.parseInt(itemId.substring(1)), nItem, quantity);

                    billScreen.append("BillID: " + billId +
                            " | ItemID: " + itemId +
                            " | Name: " + nItem.getName() +
                            " | Qty: " + quantity +
                            " | Price: " + nItem.getPrice() +
                            "\n");

                    billIdField.setText("");
                    itemIdField.setText("");
                    quantityField.setText("");
                } else {
                    JOptionPane.showMessageDialog(frame, "Item not found or insufficient stock.");
                }

            } else {
                JOptionPane.showMessageDialog(frame, "Enter All Data", "Warning", JOptionPane.WARNING_MESSAGE);
            }
        } 
        else if (ae.getSource() == calculateBillBtn) {
            billScreen.append("\n=== Total Bill: " + calculateBill() + " ===\n");
        }
        else if (ae.getSource() == confirmOrderBtn) {
            cart.confirmOrder();
            billScreen.append("\nOrder Confirmed!\n");
            updateInventoryScreen();
        }
    }

    private double calculateBill() {
        double total = 0;
        for (int i = 0; i < 100; i++) {
            CartItem item = cart.getNursery_Item(i);
            if (item != null) {
                total += item.getBill();
            }
        }
        return total;
    }

    private void updateInventoryScreen() {
        inventoryScreen.setText(inventory.toString());
    }
}