package files;
import java.io.*;//File, FileWriter, FileNotFoundException 
import java.util.*;
import entity.*;
import manager.*;

public class FileIO{
	public static void loadFromFile(Inventory inventory){
		try{
			File filePlant = new File("files/Plant.txt");
			Scanner sc = new Scanner(filePlant);
			int nurseryItemNo = 0;
			while(sc.hasNextLine()){
				String line = sc.nextLine();
				String data[] = line.split(";");
				String id = data[0];               // Plant ID
                String name = data[1];             // Plant Name
                double price = Double.parseDouble(data[2]);
                double quantity = Double.parseDouble(data[3]);
                String category = data[4];
                String season = data[5];
				
				//Plant plant = new Plant(id, name, price, quantity, category, season);
			inventory.addNurseryItem(nurseryItemNo++, new Plant(id, name, price, quantity, category, season));

			//inventory.addNurseryItem(billId++,new Plant(billId,quantity,));
			}
			sc.close();
		}catch(FileNotFoundException e){
			  System.out.println("File not found: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	}
