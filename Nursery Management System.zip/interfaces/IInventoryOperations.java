package interfaces;
import entity.*;
public interface IInventoryOperations{
	public abstract void addNurseryItem(int itemNo, NurseryItem nurseryItem);
	public abstract NurseryItem getNursery_Item(int itemNo);
	public abstract NurseryItem getNursery_ItemById(String id);
	public abstract void remove(int itemNo);
	
}